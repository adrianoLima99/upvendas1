<?php

include_once("conexao/conexao.class.php");

class Visitados {

    private $data;
    private $vendedor;
    private $gerente;
  
    private $conn;

    function __construct() {
        $this->conn = new connection();
    }

    function listagem() {
        echo "<div id='listagens'>
  <h3>Listagem de Visita</h3> ";
       if($_SESSION['tipo'] == 1)
           {
                $visibilidade=" WHERE id=$_SESSION[id]";
           }else{
                $visibilidade="";
           }    
        $listaGerente = $this->conn->query("select distinct nome,id from gerente_vendas $visibilidade ");


        if ($listaGerente->rowCount()) {
            //data anterior
            $hoje = date("d/m/Y");
            $selecao = $this->conn->query("SELECT data FROM  visita WHERE data_insercao <> '$hoje'  ORDER BY data DESC LIMIT 1 ");
            $rs = $selecao->fetch(PDO::FETCH_OBJ);
            $anterior = $rs->data_insercao;
            /////////////////
            while ($list = $listaGerente->fetch(PDO::FETCH_OBJ)) {

                echo "<div class='accordionButton'>$list->nome</div>
	   <div class='accordionContent'>";
                $sqlLista = $this->conn->query("select vis.* ,ger.nome,v.nome_vendedor,nome_produto,cli.nome as cliente,cli.tel_fixo 

                                        from visita vis,vendedor v,gerente_vendas ger,produto p,cliente cli 

                                       where vis.id_gerVendas=ger.id 

                                        and vis.id_vendedor=v.id_vendedor 
                                        and vis.id_produto=p.id_produto 
                                        and vis.id_cliente=cli.id_cliente
                                        and vis.id_gerVendas=$list->id 
                                        and vis.data_insercao ='$hoje'   
                                         order by vis.data DESC");

                if ($sqlLista->rowCount()) {

                    echo " <table>
                  <tr>
                         <th>Vendedor</th>
	 	 	
                        <th>Data da Visita</th>
			 <th>cliente</th>
			 <th>Telefone Fixo</th>
                         <th>Celular</th>
                         <th>Produto</th>
                         <th>Status</th>
                         <th>Informacoes</th>
                         <th>Alterar Visita</th>
			 
		 </tr>";
                    while ($l = $sqlLista->fetch(PDO::FETCH_OBJ)) {

                        if ($l->status == 0) {
                            $status = '<img src="imagens/status_vendido.png" alt="Vendido" title="Vendido" />';
                        } elseif ($l->status == 1) {
                            $status = '<img src="imagens/status_quente.png" alt="Quente" title="Quente" />';
                        } elseif ($l->status == 2) {
                            $status = '<img src="imagens/status_morno.png" alt="Morno" title="Morno" />';
                        }
                        echo "<tr>
                 <td>$l->nome_vendedor</td>
                 <td>$l->data</td>
                 <td>$l->cliente</td>
                 <td>$l->tel_fixo</td> 
                 <td>$l->cel1</td>     
                 <td>$l->nome_produto</td>
                 <td>$status</td>    
                 <td>$l->motivo</td>  
                  <td><a href='?pg=editarVisita&visita=$l->id_visita'>Editar</a>
                    
                  </td>      
                </tr>    
                          ";
                    }
                    echo "</table>";
                } else {
                    echo "Nenhum Registro Encontrado!";
                }
                echo "</div>";
            }
        } else {
            echo "Nenhum Registro Encontrado!";
        }
        echo "</div>";
    }

    function listagemDetalhada($data, $gerente, $vendedor) {

        if (!empty($data) && !empty($gerente) && !empty($vendedor)) {
            $this->data = $data;
            $this->gerente = $gerente;
            $this->vendedor = $vendedor;
            $sqlLista = $this->conn->query("select vis.id_visita,vis.id_vendedor,vis.id_produto,vis.status,vis.data,vis.motivo,ger.id, ger.nome ,v.id_vendedor,p.id_produto, v.nome_vendedor,nome_produto,cli.nome as cliente,cli.tel_fixo

 from visita  vis,vendedor v,gerente_vendas ger,produto p,cliente cli

 where
 vis.id_gerVendas=ger.id 
&& vis.id_vendedor=v.id_vendedor
&& vis.id_cliente = cli.id_cliente
&& vis.id_produto=p.id_produto  
&& vis.data='$this->data'
&& vis.id_vendedor=$this->vendedor
&& vis.id_gerVendas=$this->gerente");
        } else if (!empty($data)) {
            $this->data = $data;
            $sqlLista = $this->conn->query("select vis.id_visita,vis.id_vendedor,vis.id_produto,vis.status,vis.data,vis.motivo,ger.id, ger.nome ,v.id_vendedor,p.id_produto, v.nome_vendedor,nome_produto,cli.nome as cliente,cli.tel_fixo

 from visita  vis,vendedor v,gerente_vendas ger,produto p,cliente cli

 where
 vis.id_gerVendas=ger.id 
&& vis.id_vendedor=v.id_vendedor
&& vis.id_cliente = cli.id_cliente
&& vis.id_produto=p.id_produto  
&& vis.data='$this->data'
 ORDER BY vis.id_visita DESC  ");
        } else if (!empty($gerente) && empty($vendedor)) {

            $this->gerente = $gerente;
            $sqlLista = $this->conn->query("select vis.id_visita,vis.id_vendedor,vis.id_produto,vis.status ,vis.data,vis.motivo,ger.id, ger.nome ,v.id_vendedor,p.id_produto, v.nome_vendedor,nome_produto,cli.nome as cliente,cli.tel_fixo

 from visita  vis,vendedor v,gerente_vendas ger,produto p,cliente cli

 where
 vis.id_gerVendas=ger.id 
&& vis.id_vendedor=v.id_vendedor
&& vis.id_cliente = cli.id_cliente
&& vis.id_produto=p.id_produto  
&& vis.id_gerVendas=$this->gerente
ORDER BY vis.id_visita DESC  
  ");
        } else if (!empty($gerente) && !empty($vendedor)) {


            $this->vendedor = $vendedor;
            $sqlLista = $this->conn->query("select vis.id_visita,vis.id_vendedor,vis.id_produto,vis.status ,vis.data,vis.motivo,vis.id_gerVendas,ger.id, ger.nome ,v.id_vendedor,p.id_produto, v.nome_vendedor,nome_produto,cli.nome as cliente,cli.tel_fixo

 from visita  vis,vendedor v,gerente_vendas ger,produto p,cliente cli

 where
 vis.id_gerVendas=ger.id 
&& vis.id_vendedor=v.id_vendedor
&& vis.id_cliente = cli.id_cliente
&& vis.id_produto=p.id_produto  
&&  vis.id_vendedor= $this->vendedor
ORDER BY vis.id_visita DESC ");
        }

        echo "<div id='listagens'>
	  <h3>Listagem de Visita</h3> ";


        if ($sqlLista->rowCount()) {
            echo "<table cellspacing=0 cellpadding=0 border=1 width='800px'>
                <tr>
                   <th>Vendedor</th>
	 	 	
                        <th>Data da Visita</th>
			 <th>cliente</th>
			 <th>Telefone Fixo</th>
                         <th>Celular 1</th>
                         <th>Celular 2</th>
                         <th>Produto</th>
                         <th>Status</th>
                         <th>Informacoes</th>
                         <th>Alterar Visita</th>
			 
                </tr>";

            while ($linha = $sqlLista->fetch(PDO::FETCH_OBJ)) {
                      if ($linha->status == 0) {
                            $status = '<img src="imagens/status_vendido.png" alt="Vendido" title="Vendido" />';
                        } elseif ($linha->status == 1) {
                            $status = '<img src="imagens/status_quente.png" alt="Quente" title="Quente" />';
                        } elseif ($linha->status == 2) {
                            $status = '<img src="imagens/status_morno.png" alt="Morno" title="Morno" />';
                        }
                       
                echo "<tr>
                
                 <td>$linha->nome_vendedor</td>
                 <td>$linha->data</td>
                 <td>$linha->cliente</td>
                 <td>$linha->tel_fixo</td> 
                 <td>$linha->cel1</td>
                 <td>$linha->cel2</td>
                 <td>$linha->nome_produto</td>
                 <td>$status</td>    
                 <td>$linha->motivo</td>  
                  <td><a href='?pg=editarVisita&visita=$linha->id_visita'>Editar</a>
                    </td>        
                          </tr>";
            }

            echo "</table><br/></div>";
        } else {
            echo "<br/><h3>nenhum registro encontrado</h3>";
        }
    }

    function pesquisaVisita() {

if($_SESSION['tipo'] == 1)
           {
                $visibilidade=" WHERE id=$_SESSION[id]";
           }else{
                $visibilidade="";
           }    
        echo "<div id='formularios'>
	    <h3>Pesquisar por data </h3>
              <table>
                 <tr>
                  <form method='post' action='#'>
                    <td> Data:</td>
                    <td><input type='text' name='data' class='data' placeholder='Digite a data' /></td>
                  </tr>
                  <tr>
                    <td>Gerente Vendas:</td>
                    <td><select  name='gerente' id='gerente'  placeholder='Gerente de vendas' onchange = selecionaVendedor() >
                     <option></option> ";
        $sql = $this->conn->query("SELECT id,nome FROM gerente_vendas $visibilidade");
        while ($row = $sql->fetch(PDO::FETCH_OBJ)) {
            echo " <option value='$row->id'>$row->nome</option>";
        }
        echo " </select> </td>
                  </tr>
                  <tr>
                    <td> Vendedor:</td>
                    <td><select name='vendedor' id='exibir'>
                           
                    </select> 
                    </td>
                  </tr> 
                  <tr>
                    <td></td>
                    <td><input class='botao' type='submit' name='buscar' id='buscar' value='Buscar'/></td>
                  </form>
                 </tr>
               </table>
                  
                </div>";
        if (isset($_POST['buscar'])) {
            $this->listagemDetalhada($_POST['data'], $_POST['gerente'], $_POST['vendedor']);
        } else {
            $this->listagem();
        }
    }

}

?>
